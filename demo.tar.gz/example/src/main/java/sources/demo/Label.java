package sources.demo;

public class Label {
    // source作用
    public Safe source() {
        return new Safe();
    };
}
